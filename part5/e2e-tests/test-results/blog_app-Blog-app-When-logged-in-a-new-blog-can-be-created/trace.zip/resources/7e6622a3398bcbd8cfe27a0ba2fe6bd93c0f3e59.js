import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Togglable.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=806c8df3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=806c8df3"; const useState = __vite__cjsImport3_react["useState"]; const useImperativeHandle = __vite__cjsImport3_react["useImperativeHandle"]; const forwardRef = __vite__cjsImport3_react["forwardRef"];
const Togglable = _s(forwardRef(_c = _s(({
  buttonLabel,
  children
}, ref) => {
  _s();
  const [visible, setVisible] = useState(false);
  const hideWhenVisible = {
    display: visible ? "none" : ""
  };
  const showWhenVisible = {
    display: visible ? "" : "none"
  };
  const toggleVisibility = () => setVisible(!visible);
  useImperativeHandle(ref, () => {
    return {
      toggleVisibility
    };
  });
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("div", { style: hideWhenVisible, children: /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: buttonLabel }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { style: showWhenVisible, children: [
      children,
      /* @__PURE__ */ jsxDEV("button", { onClick: toggleVisibility, children: "cancel" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx",
        lineNumber: 27,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx",
      lineNumber: 25,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
}, "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=")), "7Y5lBLdF9mkfoiy3F9Lk5HPUzvA=");
_c2 = Togglable;
export default Togglable;
var _c, _c2;
$RefreshReg$(_c, "Togglable$forwardRef");
$RefreshReg$(_c2, "Togglable");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Togglable.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJROzs7Ozs7Ozs7Ozs7Ozs7OztBQWpCUixTQUFTQSxVQUFVQyxxQkFBcUJDLGtCQUFrQjtBQUUxRCxNQUFNQyxZQUFTQyxHQUFHRixXQUFVRyxLQUFBRCxHQUFDLENBQUM7QUFBQSxFQUFFRTtBQUFBQSxFQUFhQztBQUFTLEdBQUdDLFFBQVE7QUFBQUosS0FBQTtBQUMvRCxRQUFNLENBQUNLLFNBQVNDLFVBQVUsSUFBSVYsU0FBUyxLQUFLO0FBRTVDLFFBQU1XLGtCQUFrQjtBQUFBLElBQUVDLFNBQVNILFVBQVUsU0FBUztBQUFBLEVBQUc7QUFDekQsUUFBTUksa0JBQWtCO0FBQUEsSUFBRUQsU0FBU0gsVUFBVSxLQUFLO0FBQUEsRUFBTztBQUV6RCxRQUFNSyxtQkFBbUJBLE1BQU1KLFdBQVcsQ0FBQ0QsT0FBTztBQUVsRFIsc0JBQW9CTyxLQUFLLE1BQU07QUFDN0IsV0FBTztBQUFBLE1BQUVNO0FBQUFBLElBQWlCO0FBQUEsRUFDNUIsQ0FBQztBQUVELFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFNBQUksT0FBT0gsaUJBQ1YsaUNBQUMsWUFBTyxTQUFTRyxrQkFBbUJSLHlCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdELEtBRGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxPQUFPTyxpQkFDVE47QUFBQUE7QUFBQUEsTUFDRCx1QkFBQyxZQUFPLFNBQVNPLGtCQUFrQixzQkFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF5QztBQUFBLFNBRjNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUosR0FBQyxrQ0FBQztBQUFBQyxNQXZCSVo7QUF5Qk4sZUFBZUE7QUFBUyxJQUFBRSxJQUFBVTtBQUFBQyxhQUFBWCxJQUFBO0FBQUFXLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUltcGVyYXRpdmVIYW5kbGUiLCJmb3J3YXJkUmVmIiwiVG9nZ2xhYmxlIiwiX3MiLCJfYyIsImJ1dHRvbkxhYmVsIiwiY2hpbGRyZW4iLCJyZWYiLCJ2aXNpYmxlIiwic2V0VmlzaWJsZSIsImhpZGVXaGVuVmlzaWJsZSIsImRpc3BsYXkiLCJzaG93V2hlblZpc2libGUiLCJ0b2dnbGVWaXNpYmlsaXR5IiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVG9nZ2xhYmxlLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlSW1wZXJhdGl2ZUhhbmRsZSwgZm9yd2FyZFJlZiB9IGZyb20gJ3JlYWN0J1xyXG5cclxuY29uc3QgVG9nZ2xhYmxlID0gZm9yd2FyZFJlZigoeyBidXR0b25MYWJlbCwgY2hpbGRyZW4gfSwgcmVmKSA9PiB7XHJcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IGhpZGVXaGVuVmlzaWJsZSA9IHsgZGlzcGxheTogdmlzaWJsZSA/ICdub25lJyA6ICcnIH1cclxuICBjb25zdCBzaG93V2hlblZpc2libGUgPSB7IGRpc3BsYXk6IHZpc2libGUgPyAnJyA6ICdub25lJyB9XHJcblxyXG4gIGNvbnN0IHRvZ2dsZVZpc2liaWxpdHkgPSAoKSA9PiBzZXRWaXNpYmxlKCF2aXNpYmxlKVxyXG5cclxuICB1c2VJbXBlcmF0aXZlSGFuZGxlKHJlZiwgKCkgPT4ge1xyXG4gICAgcmV0dXJuIHsgdG9nZ2xlVmlzaWJpbGl0eSB9XHJcbiAgfSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXYgc3R5bGU9e2hpZGVXaGVuVmlzaWJsZX0+XHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt0b2dnbGVWaXNpYmlsaXR5fT57YnV0dG9uTGFiZWx9PC9idXR0b24+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2IHN0eWxlPXtzaG93V2hlblZpc2libGV9PlxyXG4gICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RvZ2dsZVZpc2liaWxpdHl9PmNhbmNlbDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvZGl2PlxyXG4gIClcclxufSlcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRvZ2dsYWJsZSJdLCJmaWxlIjoiRDovY2FybG8vT25lRHJpdmUvRG9jdW1lbnRvcy9DYXJyZXJhL1Byb3llY3Rvcy9WaXN1YWwgU3R1ZGlvIENvZGUvZnVsbHN0YWNrb3Blbl9leGVyY2lzZXMvcGFydDUvc3JjL2NvbXBvbmVudHMvVG9nZ2xhYmxlLmpzeCJ9