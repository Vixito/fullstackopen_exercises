import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=806c8df3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=806c8df3"; const useState = __vite__cjsImport3_react["useState"];
const BlogForm = ({
  createBlog
}) => {
  _s();
  const [title, setTitle] = useState("");
  const [author, setAuthor] = useState("");
  const [url, setUrl] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    createBlog({
      title,
      author,
      url
    });
    setTitle("");
    setAuthor("");
    setUrl("");
  };
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "title", children: "title" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "title", type: "text", value: title, name: "Title", onChange: ({
        target
      }) => setTitle(target.value) }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 24,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "author", children: "author" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 29,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "author", type: "text", value: author, name: "Author", onChange: ({
        target
      }) => setAuthor(target.value) }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 30,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("label", { htmlFor: "url", children: "url" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 35,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { id: "url", type: "text", value: url, name: "Url", onChange: ({
        target
      }) => setUrl(target.value) }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
        lineNumber: 36,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "create" }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
      lineNumber: 40,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(BlogForm, "g+g+3j1LiFjJCP23+NliFDHOHt4=");
_c = BlogForm;
export default BlogForm;
var _c;
$RefreshReg$(_c, "BlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/BlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsV0FBV0EsQ0FBQztBQUFBLEVBQUVDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ25DLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJTCxTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDTSxRQUFRQyxTQUFTLElBQUlQLFNBQVMsRUFBRTtBQUN2QyxRQUFNLENBQUNRLEtBQUtDLE1BQU0sSUFBSVQsU0FBUyxFQUFFO0FBRWpDLFFBQU1VLGVBQWdCQyxXQUFVO0FBQzlCQSxVQUFNQyxlQUFlO0FBQ3JCVixlQUFXO0FBQUEsTUFDVEU7QUFBQUEsTUFDQUU7QUFBQUEsTUFDQUU7QUFBQUEsSUFDRixDQUFDO0FBQ0RILGFBQVMsRUFBRTtBQUNYRSxjQUFVLEVBQUU7QUFDWkUsV0FBTyxFQUFFO0FBQUEsRUFDWDtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxVQUFVQyxjQUNkO0FBQUEsMkJBQUMsU0FDQztBQUFBLDZCQUFDLFdBQU0sU0FBUSxTQUFRLHFCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTRCO0FBQUEsTUFDNUIsdUJBQUMsV0FDQyxJQUFHLFNBQ0gsTUFBSyxRQUNMLE9BQU9OLE9BQ1AsTUFBSyxTQUNMLFVBQVUsQ0FBQztBQUFBLFFBQUVTO0FBQUFBLE1BQU8sTUFBTVIsU0FBU1EsT0FBT0MsS0FBSyxLQUxqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS21EO0FBQUEsU0FQckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsV0FBTSxTQUFRLFVBQVMsc0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEI7QUFBQSxNQUM5Qix1QkFBQyxXQUNDLElBQUcsVUFDSCxNQUFLLFFBQ0wsT0FBT1IsUUFDUCxNQUFLLFVBQ0wsVUFBVSxDQUFDO0FBQUEsUUFBRU87QUFBQUEsTUFBTyxNQUFNTixVQUFVTSxPQUFPQyxLQUFLLEtBTGxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLb0Q7QUFBQSxTQVB0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxXQUFNLFNBQVEsT0FBTSxtQkFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLFdBQ0MsSUFBRyxPQUNILE1BQUssUUFDTCxPQUFPTixLQUNQLE1BQUssT0FDTCxVQUFVLENBQUM7QUFBQSxRQUFFSztBQUFBQSxNQUFPLE1BQU1KLE9BQU9JLE9BQU9DLEtBQUssS0FML0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtpRDtBQUFBLFNBUG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxNQUFLLFVBQVMsc0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEI7QUFBQSxPQS9COUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdDQTtBQUVKO0FBQUNYLEdBcERLRixVQUFRO0FBQUFjLEtBQVJkO0FBc0ROLGVBQWVBO0FBQVEsSUFBQWM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwiX3MiLCJ0aXRsZSIsInNldFRpdGxlIiwiYXV0aG9yIiwic2V0QXV0aG9yIiwidXJsIiwic2V0VXJsIiwiaGFuZGxlU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuXHJcbmNvbnN0IEJsb2dGb3JtID0gKHsgY3JlYXRlQmxvZyB9KSA9PiB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbYXV0aG9yLCBzZXRBdXRob3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW3VybCwgc2V0VXJsXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZXZlbnQpID0+IHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIGNyZWF0ZUJsb2coe1xyXG4gICAgICB0aXRsZSxcclxuICAgICAgYXV0aG9yLFxyXG4gICAgICB1cmwsXHJcbiAgICB9KVxyXG4gICAgc2V0VGl0bGUoJycpXHJcbiAgICBzZXRBdXRob3IoJycpXHJcbiAgICBzZXRVcmwoJycpXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ0aXRsZVwiPnRpdGxlPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwidGl0bGVcIlxyXG4gICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgdmFsdWU9e3RpdGxlfVxyXG4gICAgICAgICAgbmFtZT1cIlRpdGxlXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VGl0bGUodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPGRpdj5cclxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImF1dGhvclwiPmF1dGhvcjwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD1cImF1dGhvclwiXHJcbiAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICB2YWx1ZT17YXV0aG9yfVxyXG4gICAgICAgICAgbmFtZT1cIkF1dGhvclwiXHJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldEF1dGhvcih0YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXJsXCI+dXJsPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwidXJsXCJcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIHZhbHVlPXt1cmx9XHJcbiAgICAgICAgICBuYW1lPVwiVXJsXCJcclxuICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXJsKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgLz5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmNyZWF0ZTwvYnV0dG9uPlxyXG4gICAgPC9mb3JtPlxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmxvZ0Zvcm0iXSwiZmlsZSI6IkQ6L2NhcmxvL09uZURyaXZlL0RvY3VtZW50b3MvQ2FycmVyYS9Qcm95ZWN0b3MvVmlzdWFsIFN0dWRpbyBDb2RlL2Z1bGxzdGFja29wZW5fZXhlcmNpc2VzL3BhcnQ1L3NyYy9jb21wb25lbnRzL0Jsb2dGb3JtLmpzeCJ9