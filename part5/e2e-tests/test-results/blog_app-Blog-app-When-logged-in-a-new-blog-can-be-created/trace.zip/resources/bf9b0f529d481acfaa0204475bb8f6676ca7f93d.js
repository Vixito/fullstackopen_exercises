import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=806c8df3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=806c8df3"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import Blog from "/src/components/Blog.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
import BlogForm from "/src/components/BlogForm.jsx?t=1751132240487";
import Togglable from "/src/components/Togglable.jsx";
const Notification = ({
  message,
  type
}) => {
  if (!message)
    return null;
  const style = {
    color: type === "success" ? "green" : "red",
    background: "#f4f4f4",
    fontSize: 20,
    border: `2px solid ${type === "success" ? "green" : "red"}`,
    borderRadius: 5,
    padding: 10,
    marginBottom: 20,
    textAlign: "center"
  };
  return /* @__PURE__ */ jsxDEV("div", { style, children: message }, void 0, false, {
    fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
};
_c = Notification;
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const blogFormRef = useRef();
  useEffect(() => {
    blogService.getAll().then((blogs2) => setBlogs(blogs2));
  }, []);
  useEffect(() => {
    const loggedUserJSON = window.localStorage.getItem("loggedBlogAppUser");
    if (loggedUserJSON) {
      const user2 = JSON.parse(loggedUserJSON);
      setUser(user2);
      blogService.setToken && blogService.setToken(user2.token);
    }
  }, []);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const userData = await loginService.login({
        username,
        password
      });
      window.localStorage.setItem("loggedBlogAppUser", JSON.stringify(userData));
      setUser(userData);
      setUsername("");
      setPassword("");
      blogService.setToken && blogService.setToken(userData.token);
      setSuccessMessage("Login successful!");
      setTimeout(() => setSuccessMessage(null), 4e3);
    } catch (error) {
      setErrorMessage("Wrong credentials");
      setTimeout(() => setErrorMessage(null), 4e3);
    }
  };
  const handleLogout = () => {
    window.localStorage.removeItem("loggedBlogAppUser");
    setUser(null);
    blogService.setToken && blogService.setToken(null);
    setSuccessMessage("Logged out");
    setTimeout(() => setSuccessMessage(null), 4e3);
  };
  const addBlog = async (blogObject) => {
    try {
      const returnedBlog = await blogService.create(blogObject);
      setBlogs(blogs.concat(returnedBlog));
      setSuccessMessage(`A new blog "${returnedBlog.title}" by ${returnedBlog.author} added!`);
      setTimeout(() => setSuccessMessage(null), 4e3);
      blogFormRef.current.toggleVisibility();
    } catch (error) {
      setErrorMessage("Error adding blog");
      setTimeout(() => setErrorMessage(null), 4e3);
    }
  };
  const handleLike = async (updatedBlog) => {
    try {
      const blogToUpdate = {
        user: updatedBlog.user.id || updatedBlog.user,
        // Ya lo tenía hecho
        likes: updatedBlog.likes,
        author: updatedBlog.author,
        title: updatedBlog.title,
        url: updatedBlog.url
      };
      const returnedBlog = await blogService.update(updatedBlog.id, blogToUpdate);
      setBlogs(blogs.map((b) => b.id === updatedBlog.id ? {
        ...returnedBlog,
        user: updatedBlog.user
      } : b));
    } catch (error) {
      setErrorMessage("Error updating likes");
      setTimeout(() => setErrorMessage(null), 4e3);
    }
  };
  const handleRemove = async (blogToRemove) => {
    try {
      await blogService.remove(blogToRemove.id);
      setBlogs(blogs.filter((b) => b.id !== blogToRemove.id));
      setSuccessMessage(`Blog "${blogToRemove.title}" removed`);
      setTimeout(() => setSuccessMessage(null), 4e3);
    } catch (error) {
      setErrorMessage("Error removing blog");
      setTimeout(() => setErrorMessage(null), 4e3);
    }
  };
  if (user === null) {
    return /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
        lineNumber: 127,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage, type: "error" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
        lineNumber: 128,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Notification, { message: successMessage, type: "success" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
        lineNumber: 129,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
        /* @__PURE__ */ jsxDEV("div", { children: [
          "username",
          /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, name: "Username", onChange: ({
            target
          }) => setUsername(target.value) }, void 0, false, {
            fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
            lineNumber: 133,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
          lineNumber: 131,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { children: [
          "password",
          /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, name: "Password", onChange: ({
            target
          }) => setPassword(target.value) }, void 0, false, {
            fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
            lineNumber: 139,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
          lineNumber: 137,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "login" }, void 0, false, {
          fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
          lineNumber: 143,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
        lineNumber: 130,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 126,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "blogs" }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 148,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: errorMessage, type: "error" }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 149,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message: successMessage, type: "success" }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 150,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " logged in",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "logout" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
        lineNumber: 153,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 151,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "create new blog", ref: blogFormRef, children: /* @__PURE__ */ jsxDEV(BlogForm, { createBlog: addBlog }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 156,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 155,
      columnNumber: 7
    }, this),
    blogs.slice().sort((a, b) => b.likes - a.likes).map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, handleLike, handleRemove, currentUser: user }, blog.id, false, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
      lineNumber: 159,
      columnNumber: 52
    }, this))
  ] }, void 0, true, {
    fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx",
    lineNumber: 147,
    columnNumber: 10
  }, this);
};
_s(App, "Zl6iLvK4Xq9M0u4eGhCzQH9Umj8=");
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Notification");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JTOzs7Ozs7Ozs7Ozs7Ozs7OztBQXBCVCxTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLFVBQVU7QUFDakIsT0FBT0MsaUJBQWlCO0FBQ3hCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxjQUFjO0FBQ3JCLE9BQU9DLGVBQWU7QUFHdEIsTUFBTUMsZUFBZUEsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVNDO0FBQUssTUFBTTtBQUMxQyxNQUFJLENBQUNEO0FBQVMsV0FBTztBQUNyQixRQUFNRSxRQUFRO0FBQUEsSUFDWkMsT0FBT0YsU0FBUyxZQUFZLFVBQVU7QUFBQSxJQUN0Q0csWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxRQUFTLGFBQVlMLFNBQVMsWUFBWSxVQUFVLEtBQU07QUFBQSxJQUMxRE0sY0FBYztBQUFBLElBQ2RDLFNBQVM7QUFBQSxJQUNUQyxjQUFjO0FBQUEsSUFDZEMsV0FBVztBQUFBLEVBQ2I7QUFDQSxTQUFPLHVCQUFDLFNBQUksT0FBZVYscUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEI7QUFDckM7QUFBQ1csS0FiS1o7QUFlTixNQUFNYSxNQUFNQSxNQUFNO0FBQUFDLEtBQUE7QUFDaEIsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUl4QixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDeUIsTUFBTUMsT0FBTyxJQUFJMUIsU0FBUyxJQUFJO0FBQ3JDLFFBQU0sQ0FBQzJCLFVBQVVDLFdBQVcsSUFBSTVCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUM2QixVQUFVQyxXQUFXLElBQUk5QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDK0IsY0FBY0MsZUFBZSxJQUFJaEMsU0FBUyxJQUFJO0FBQ3JELFFBQU0sQ0FBQ2lDLGdCQUFnQkMsaUJBQWlCLElBQUlsQyxTQUFTLElBQUk7QUFDekQsUUFBTW1DLGNBQWNqQyxPQUFPO0FBRTNCRCxZQUFVLE1BQU07QUFDZEcsZ0JBQVlnQyxPQUFPLEVBQUVDLEtBQUtkLFlBQ3hCQyxTQUFVRCxNQUFNLENBQ2xCO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFHTHRCLFlBQVUsTUFBTTtBQUNkLFVBQU1xQyxpQkFBaUJDLE9BQU9DLGFBQWFDLFFBQVEsbUJBQW1CO0FBQ3RFLFFBQUlILGdCQUFnQjtBQUNsQixZQUFNYixRQUFPaUIsS0FBS0MsTUFBTUwsY0FBYztBQUN0Q1osY0FBUUQsS0FBSTtBQUVackIsa0JBQVl3QyxZQUFZeEMsWUFBWXdDLFNBQVNuQixNQUFLb0IsS0FBSztBQUFBLElBQ3pEO0FBQUEsRUFDRixHQUFHLEVBQUU7QUFFTCxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFDckIsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTTVDLGFBQWE2QyxNQUFNO0FBQUEsUUFBRXZCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUNoRVUsYUFBT0MsYUFBYVcsUUFBUSxxQkFBcUJULEtBQUtVLFVBQVVILFFBQVEsQ0FBQztBQUN6RXZCLGNBQVF1QixRQUFRO0FBQ2hCckIsa0JBQVksRUFBRTtBQUNkRSxrQkFBWSxFQUFFO0FBQ2QxQixrQkFBWXdDLFlBQVl4QyxZQUFZd0MsU0FBU0ssU0FBU0osS0FBSztBQUMzRFgsd0JBQWtCLG1CQUFtQjtBQUNyQ21CLGlCQUFXLE1BQU1uQixrQkFBa0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUNoRCxTQUFTb0IsT0FBTztBQUNkdEIsc0JBQWdCLG1CQUFtQjtBQUNuQ3FCLGlCQUFXLE1BQU1yQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFHQSxRQUFNdUIsZUFBZUEsTUFBTTtBQUN6QmhCLFdBQU9DLGFBQWFnQixXQUFXLG1CQUFtQjtBQUNsRDlCLFlBQVEsSUFBSTtBQUVadEIsZ0JBQVl3QyxZQUFZeEMsWUFBWXdDLFNBQVMsSUFBSTtBQUNqRFYsc0JBQWtCLFlBQVk7QUFDOUJtQixlQUFXLE1BQU1uQixrQkFBa0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxFQUNoRDtBQUdBLFFBQU11QixVQUFVLE9BQU9DLGVBQWU7QUFDcEMsUUFBSTtBQUNGLFlBQU1DLGVBQWUsTUFBTXZELFlBQVl3RCxPQUFPRixVQUFVO0FBQ3hEbEMsZUFBU0QsTUFBTXNDLE9BQU9GLFlBQVksQ0FBQztBQUNuQ3pCLHdCQUFtQixlQUFjeUIsYUFBYUcsS0FBTSxRQUFPSCxhQUFhSSxNQUFPLFNBQVE7QUFDdkZWLGlCQUFXLE1BQU1uQixrQkFBa0IsSUFBSSxHQUFHLEdBQUk7QUFDOUNDLGtCQUFZNkIsUUFBUUMsaUJBQWlCO0FBQUEsSUFDdkMsU0FBU1gsT0FBTztBQUNkdEIsc0JBQWdCLG1CQUFtQjtBQUNuQ3FCLGlCQUFXLE1BQU1yQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxRQUFNa0MsYUFBYSxPQUFPQyxnQkFBZ0I7QUFDeEMsUUFBSTtBQUNGLFlBQU1DLGVBQWU7QUFBQSxRQUNuQjNDLE1BQU0wQyxZQUFZMUMsS0FBSzRDLE1BQU1GLFlBQVkxQztBQUFBQTtBQUFBQSxRQUN6QzZDLE9BQU9ILFlBQVlHO0FBQUFBLFFBQ25CUCxRQUFRSSxZQUFZSjtBQUFBQSxRQUNwQkQsT0FBT0ssWUFBWUw7QUFBQUEsUUFDbkJTLEtBQUtKLFlBQVlJO0FBQUFBLE1BQ25CO0FBQ0EsWUFBTVosZUFBZSxNQUFNdkQsWUFBWW9FLE9BQU9MLFlBQVlFLElBQUlELFlBQVk7QUFDMUU1QyxlQUFTRCxNQUFNa0QsSUFBSUMsT0FBS0EsRUFBRUwsT0FBT0YsWUFBWUUsS0FBSztBQUFBLFFBQUUsR0FBR1Y7QUFBQUEsUUFBY2xDLE1BQU0wQyxZQUFZMUM7QUFBQUEsTUFBSyxJQUFJaUQsQ0FBQyxDQUFDO0FBQUEsSUFDcEcsU0FBU3BCLE9BQU87QUFDZHRCLHNCQUFnQixzQkFBc0I7QUFDdENxQixpQkFBVyxNQUFNckIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0FBQUEsSUFDOUM7QUFBQSxFQUNGO0FBRUEsUUFBTTJDLGVBQWUsT0FBT0MsaUJBQWlCO0FBQzNDLFFBQUk7QUFDRixZQUFNeEUsWUFBWXlFLE9BQU9ELGFBQWFQLEVBQUU7QUFDeEM3QyxlQUFTRCxNQUFNdUQsT0FBT0osT0FBS0EsRUFBRUwsT0FBT08sYUFBYVAsRUFBRSxDQUFDO0FBQ3BEbkMsd0JBQW1CLFNBQVEwQyxhQUFhZCxLQUFNLFdBQVU7QUFDeERULGlCQUFXLE1BQU1uQixrQkFBa0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUNoRCxTQUFTb0IsT0FBTztBQUNkdEIsc0JBQWdCLHFCQUFxQjtBQUNyQ3FCLGlCQUFXLE1BQU1yQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7QUFBQSxJQUM5QztBQUFBLEVBQ0Y7QUFFQSxNQUFJUCxTQUFTLE1BQU07QUFDakIsV0FDRSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsUUFBRyxxQ0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXlCO0FBQUEsTUFDekIsdUJBQUMsZ0JBQWEsU0FBU00sY0FBYyxNQUFLLFdBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUQ7QUFBQSxNQUNqRCx1QkFBQyxnQkFBYSxTQUFTRSxnQkFBZ0IsTUFBSyxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFDckQsdUJBQUMsVUFBSyxVQUFVYSxhQUNkO0FBQUEsK0JBQUMsU0FBSTtBQUFBO0FBQUEsVUFFSCx1QkFBQyxXQUNDLE1BQUssUUFDTCxPQUFPbkIsVUFDUCxNQUFLLFlBQ0wsVUFBVSxDQUFDO0FBQUEsWUFBRW9EO0FBQUFBLFVBQU8sTUFBTW5ELFlBQVltRCxPQUFPQyxLQUFLLEtBSnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSXNEO0FBQUEsYUFOeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsUUFDQSx1QkFBQyxTQUFJO0FBQUE7QUFBQSxVQUVILHVCQUFDLFdBQ0MsTUFBSyxZQUNMLE9BQU9uRCxVQUNQLE1BQUssWUFDTCxVQUFVLENBQUM7QUFBQSxZQUFFa0Q7QUFBQUEsVUFBTyxNQUFNakQsWUFBWWlELE9BQU9DLEtBQUssS0FKcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFJc0Q7QUFBQSxhQU54RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFlBQU8sTUFBSyxVQUFTLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJCO0FBQUEsV0FuQjdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxTQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsRUFFSjtBQUVBLFNBQ0UsdUJBQUMsU0FDQztBQUFBLDJCQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxnQkFBYSxTQUFTakQsY0FBYyxNQUFLLFdBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUQ7QUFBQSxJQUNqRCx1QkFBQyxnQkFBYSxTQUFTRSxnQkFBZ0IsTUFBSyxhQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXFEO0FBQUEsSUFDckQsdUJBQUMsU0FDRVI7QUFBQUEsV0FBS3dEO0FBQUFBLE1BQUs7QUFBQSxNQUNYLHVCQUFDLFlBQU8sU0FBUzFCLGNBQWMsc0JBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxTQUZ2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUNBLHVCQUFDLGFBQVUsYUFBWSxtQkFBa0IsS0FBS3BCLGFBQzVDLGlDQUFDLFlBQVMsWUFBWXNCLFdBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBOEIsS0FEaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ2xDLE1BQ0UyRCxNQUFNLEVBQ05DLEtBQUssQ0FBQ0MsR0FBR1YsTUFBTUEsRUFBRUosUUFBUWMsRUFBRWQsS0FBSyxFQUNoQ0csSUFBSVksVUFDSCx1QkFBQyxRQUVDLE1BQ0EsWUFDQSxjQUNBLGFBQWE1RCxRQUpSNEQsS0FBS2hCLElBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtvQixDQUV4QjtBQUFBLE9BdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F1QkE7QUFFSjtBQUFDL0MsR0F6SktELEtBQUc7QUFBQWlFLE1BQUhqRTtBQTJKTixlQUFlQTtBQUFHLElBQUFELElBQUFrRTtBQUFBQyxhQUFBbkUsSUFBQTtBQUFBbUUsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQmxvZyIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQmxvZ0Zvcm0iLCJUb2dnbGFibGUiLCJOb3RpZmljYXRpb24iLCJtZXNzYWdlIiwidHlwZSIsInN0eWxlIiwiY29sb3IiLCJiYWNrZ3JvdW5kIiwiZm9udFNpemUiLCJib3JkZXIiLCJib3JkZXJSYWRpdXMiLCJwYWRkaW5nIiwibWFyZ2luQm90dG9tIiwidGV4dEFsaWduIiwiX2MiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VyIiwic2V0VXNlciIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwiZXJyb3JNZXNzYWdlIiwic2V0RXJyb3JNZXNzYWdlIiwic3VjY2Vzc01lc3NhZ2UiLCJzZXRTdWNjZXNzTWVzc2FnZSIsImJsb2dGb3JtUmVmIiwiZ2V0QWxsIiwidGhlbiIsImxvZ2dlZFVzZXJKU09OIiwid2luZG93IiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ1c2VyRGF0YSIsImxvZ2luIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsInNldFRpbWVvdXQiLCJlcnJvciIsImhhbmRsZUxvZ291dCIsInJlbW92ZUl0ZW0iLCJhZGRCbG9nIiwiYmxvZ09iamVjdCIsInJldHVybmVkQmxvZyIsImNyZWF0ZSIsImNvbmNhdCIsInRpdGxlIiwiYXV0aG9yIiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJoYW5kbGVMaWtlIiwidXBkYXRlZEJsb2ciLCJibG9nVG9VcGRhdGUiLCJpZCIsImxpa2VzIiwidXJsIiwidXBkYXRlIiwibWFwIiwiYiIsImhhbmRsZVJlbW92ZSIsImJsb2dUb1JlbW92ZSIsInJlbW92ZSIsImZpbHRlciIsInRhcmdldCIsInZhbHVlIiwibmFtZSIsInNsaWNlIiwic29ydCIsImEiLCJibG9nIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXHJcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xyXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXHJcbmltcG9ydCBCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQmxvZ0Zvcm0nXHJcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcclxuXHJcbi8vIE5vdGlmaWNhY2nDs24gcmV1dGlsaXphYmxlXHJcbmNvbnN0IE5vdGlmaWNhdGlvbiA9ICh7IG1lc3NhZ2UsIHR5cGUgfSkgPT4ge1xyXG4gIGlmICghbWVzc2FnZSkgcmV0dXJuIG51bGxcclxuICBjb25zdCBzdHlsZSA9IHtcclxuICAgIGNvbG9yOiB0eXBlID09PSAnc3VjY2VzcycgPyAnZ3JlZW4nIDogJ3JlZCcsXHJcbiAgICBiYWNrZ3JvdW5kOiAnI2Y0ZjRmNCcsXHJcbiAgICBmb250U2l6ZTogMjAsXHJcbiAgICBib3JkZXI6IGAycHggc29saWQgJHt0eXBlID09PSAnc3VjY2VzcycgPyAnZ3JlZW4nIDogJ3JlZCd9YCxcclxuICAgIGJvcmRlclJhZGl1czogNSxcclxuICAgIHBhZGRpbmc6IDEwLFxyXG4gICAgbWFyZ2luQm90dG9tOiAyMCxcclxuICAgIHRleHRBbGlnbjogJ2NlbnRlcidcclxuICB9XHJcbiAgcmV0dXJuIDxkaXYgc3R5bGU9e3N0eWxlfT57bWVzc2FnZX08L2Rpdj5cclxufVxyXG5cclxuY29uc3QgQXBwID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXHJcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcclxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2Vycm9yTWVzc2FnZSwgc2V0RXJyb3JNZXNzYWdlXSA9IHVzZVN0YXRlKG51bGwpXHJcbiAgY29uc3QgW3N1Y2Nlc3NNZXNzYWdlLCBzZXRTdWNjZXNzTWVzc2FnZV0gPSB1c2VTdGF0ZShudWxsKVxyXG4gIGNvbnN0IGJsb2dGb3JtUmVmID0gdXNlUmVmKClcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT5cclxuICAgICAgc2V0QmxvZ3MoIGJsb2dzIClcclxuICAgICkgIFxyXG4gIH0sIFtdKVxyXG5cclxuICAvLyBSZXZpc2FyIHNpIGhheSB1c3VhcmlvIGd1YXJkYWRvIGVuIGxvY2FsU3RvcmFnZSBhbCBpbmljaWFyXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGNvbnN0IGxvZ2dlZFVzZXJKU09OID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRCbG9nQXBwVXNlcicpXHJcbiAgICBpZiAobG9nZ2VkVXNlckpTT04pIHtcclxuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UobG9nZ2VkVXNlckpTT04pXHJcbiAgICAgIHNldFVzZXIodXNlcilcclxuICAgICAgLy8gU2kgbmVjZXNpdG8gdG9rZW4gcGFyYSBwZXRpY2lvbmVzOlxyXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbiAmJiBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxyXG4gICAgfVxyXG4gIH0sIFtdKVxyXG5cclxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlckRhdGEgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSlcclxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKCdsb2dnZWRCbG9nQXBwVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXJEYXRhKSlcclxuICAgICAgc2V0VXNlcih1c2VyRGF0YSlcclxuICAgICAgc2V0VXNlcm5hbWUoJycpXHJcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxyXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbiAmJiBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyRGF0YS50b2tlbilcclxuICAgICAgc2V0U3VjY2Vzc01lc3NhZ2UoJ0xvZ2luIHN1Y2Nlc3NmdWwhJylcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdWNjZXNzTWVzc2FnZShudWxsKSwgNDAwMClcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnV3JvbmcgY3JlZGVudGlhbHMnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEVycm9yTWVzc2FnZShudWxsKSwgNDAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIENlcnJhciBzZXNpw7NuXHJcbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xyXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRCbG9nQXBwVXNlcicpXHJcbiAgICBzZXRVc2VyKG51bGwpXHJcbiAgICAvLyBTaSB1c28gdG9rZW4sIHNlIHBvZHLDrWEgbGltcGlhciBhcXXDrSB0YW1iacOpblxyXG4gICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4gJiYgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4obnVsbClcclxuICAgIHNldFN1Y2Nlc3NNZXNzYWdlKCdMb2dnZWQgb3V0JylcclxuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3VjY2Vzc01lc3NhZ2UobnVsbCksIDQwMDApXHJcbiAgfVxyXG5cclxuICAvLyBOdWV2YSBmdW5jacOzbiBwYXJhIGNyZWFyIHVuIGJsb2csIGxsYW1hZGEgcG9yIEJsb2dGb3JtXHJcbiAgY29uc3QgYWRkQmxvZyA9IGFzeW5jIChibG9nT2JqZWN0KSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXR1cm5lZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGUoYmxvZ09iamVjdClcclxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KHJldHVybmVkQmxvZykpXHJcbiAgICAgIHNldFN1Y2Nlc3NNZXNzYWdlKGBBIG5ldyBibG9nIFwiJHtyZXR1cm5lZEJsb2cudGl0bGV9XCIgYnkgJHtyZXR1cm5lZEJsb2cuYXV0aG9yfSBhZGRlZCFgKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN1Y2Nlc3NNZXNzYWdlKG51bGwpLCA0MDAwKVxyXG4gICAgICBibG9nRm9ybVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKSAvLyBPY3VsdGEgZWwgZm9ybXVsYXJpbyBkZXNwdcOpcyBkZSBjcmVhciBlbCBibG9nXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0Vycm9yIGFkZGluZyBibG9nJylcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRFcnJvck1lc3NhZ2UobnVsbCksIDQwMDApXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBjb25zdCBoYW5kbGVMaWtlID0gYXN5bmMgKHVwZGF0ZWRCbG9nKSA9PiB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBibG9nVG9VcGRhdGUgPSB7XHJcbiAgICAgICAgdXNlcjogdXBkYXRlZEJsb2cudXNlci5pZCB8fCB1cGRhdGVkQmxvZy51c2VyLCAvLyBZYSBsbyB0ZW7DrWEgaGVjaG9cclxuICAgICAgICBsaWtlczogdXBkYXRlZEJsb2cubGlrZXMsXHJcbiAgICAgICAgYXV0aG9yOiB1cGRhdGVkQmxvZy5hdXRob3IsXHJcbiAgICAgICAgdGl0bGU6IHVwZGF0ZWRCbG9nLnRpdGxlLFxyXG4gICAgICAgIHVybDogdXBkYXRlZEJsb2cudXJsXHJcbiAgICAgIH1cclxuICAgICAgY29uc3QgcmV0dXJuZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlKHVwZGF0ZWRCbG9nLmlkLCBibG9nVG9VcGRhdGUpXHJcbiAgICAgIHNldEJsb2dzKGJsb2dzLm1hcChiID0+IGIuaWQgPT09IHVwZGF0ZWRCbG9nLmlkID8geyAuLi5yZXR1cm5lZEJsb2csIHVzZXI6IHVwZGF0ZWRCbG9nLnVzZXIgfSA6IGIpKSAvLyBZYSBsbyB0ZW7DrWEgaGVjaG9cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnRXJyb3IgdXBkYXRpbmcgbGlrZXMnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEVycm9yTWVzc2FnZShudWxsKSwgNDAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGNvbnN0IGhhbmRsZVJlbW92ZSA9IGFzeW5jIChibG9nVG9SZW1vdmUpID0+IHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnJlbW92ZShibG9nVG9SZW1vdmUuaWQpXHJcbiAgICAgIHNldEJsb2dzKGJsb2dzLmZpbHRlcihiID0+IGIuaWQgIT09IGJsb2dUb1JlbW92ZS5pZCkpXHJcbiAgICAgIHNldFN1Y2Nlc3NNZXNzYWdlKGBCbG9nIFwiJHtibG9nVG9SZW1vdmUudGl0bGV9XCIgcmVtb3ZlZGApXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3VjY2Vzc01lc3NhZ2UobnVsbCksIDQwMDApXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBzZXRFcnJvck1lc3NhZ2UoJ0Vycm9yIHJlbW92aW5nIGJsb2cnKVxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEVycm9yTWVzc2FnZShudWxsKSwgNDAwMClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlmICh1c2VyID09PSBudWxsKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIDxoMj5Mb2cgaW4gdG8gYXBwbGljYXRpb248L2gyPlxyXG4gICAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17ZXJyb3JNZXNzYWdlfSB0eXBlPVwiZXJyb3JcIiAvPlxyXG4gICAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17c3VjY2Vzc01lc3NhZ2V9IHR5cGU9XCJzdWNjZXNzXCIgLz5cclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgdXNlcm5hbWVcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cclxuICAgICAgICAgICAgICBuYW1lPVwiVXNlcm5hbWVcIlxyXG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgcGFzc3dvcmRcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgbmFtZT1cIlBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiPmxvZ2luPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIClcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDI+YmxvZ3M8L2gyPlxyXG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e2Vycm9yTWVzc2FnZX0gdHlwZT1cImVycm9yXCIgLz5cclxuICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXtzdWNjZXNzTWVzc2FnZX0gdHlwZT1cInN1Y2Nlc3NcIiAvPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHt1c2VyLm5hbWV9IGxvZ2dlZCBpblxyXG4gICAgICAgIDxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5sb2dvdXQ8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9XCJjcmVhdGUgbmV3IGJsb2dcIiByZWY9e2Jsb2dGb3JtUmVmfT5cclxuICAgICAgICA8QmxvZ0Zvcm0gY3JlYXRlQmxvZz17YWRkQmxvZ30gLz5cclxuICAgICAgPC9Ub2dnbGFibGU+XHJcbiAgICAgIHtibG9nc1xyXG4gICAgICAgIC5zbGljZSgpIC8vIGNvcGlhIHBhcmEgbm8gbXV0YXIgZWwgZXN0YWRvIG9yaWdpbmFsXHJcbiAgICAgICAgLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKVxyXG4gICAgICAgIC5tYXAoYmxvZyA9PlxyXG4gICAgICAgICAgPEJsb2dcclxuICAgICAgICAgICAga2V5PXtibG9nLmlkfVxyXG4gICAgICAgICAgICBibG9nPXtibG9nfVxyXG4gICAgICAgICAgICBoYW5kbGVMaWtlPXtoYW5kbGVMaWtlfVxyXG4gICAgICAgICAgICBoYW5kbGVSZW1vdmU9e2hhbmRsZVJlbW92ZX1cclxuICAgICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6IkQ6L2NhcmxvL09uZURyaXZlL0RvY3VtZW50b3MvQ2FycmVyYS9Qcm95ZWN0b3MvVmlzdWFsIFN0dWRpbyBDb2RlL2Z1bGxzdGFja29wZW5fZXhlcmNpc2VzL3BhcnQ1L3NyYy9BcHAuanN4In0=