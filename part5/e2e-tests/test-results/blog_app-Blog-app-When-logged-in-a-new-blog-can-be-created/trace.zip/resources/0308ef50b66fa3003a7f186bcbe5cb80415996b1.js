import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=806c8df3"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=af7c6055"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=806c8df3"; const useState = __vite__cjsImport4_react["useState"];
const Blog = ({
  blog,
  handleLike,
  handleRemove,
  currentUser
}) => {
  _s();
  const [showDetails, setShowDetails] = useState(false);
  const blogStyle = {
    padding: 10,
    border: "1px solid #ccc",
    marginBottom: 5,
    borderRadius: 4,
    background: "#f9f9f9"
  };
  const likeBlog = () => {
    handleLike({
      ...blog,
      likes: blog.likes + 1,
      user: blog.user.id || blog.user
    });
  };
  const removeBlog = () => {
    if (window.confirm(`Remove blog "${blog.title}" by ${blog.author}?`)) {
      handleRemove(blog);
    }
  };
  const isOwner = blog.user && (blog.user.username === currentUser.username || blog.user === currentUser.id);
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, className: "blog", children: [
    /* @__PURE__ */ jsxDEV("div", { children: [
      blog.title,
      " ",
      blog.author,
      /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowDetails(!showDetails), children: showDetails ? "hide" : "view" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    showDetails && /* @__PURE__ */ jsxDEV("div", { className: "blogDetails", children: [
      /* @__PURE__ */ jsxDEV("div", { children: blog.url }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
        lineNumber: 42,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        "likes ",
        blog.likes,
        /* @__PURE__ */ jsxDEV("button", { onClick: likeBlog, children: "like" }, void 0, false, {
          fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
          lineNumber: 45,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
        lineNumber: 43,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: blog.user && blog.user.name }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
        lineNumber: 47,
        columnNumber: 11
      }, this),
      isOwner && /* @__PURE__ */ jsxDEV("button", { onClick: removeBlog, style: {
        background: "red",
        color: "white"
      }, children: "remove" }, void 0, false, {
        fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
        lineNumber: 48,
        columnNumber: 23
      }, this)
    ] }, void 0, true, {
      fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
      lineNumber: 41,
      columnNumber: 23
    }, this)
  ] }, void 0, true, {
    fileName: "D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(Blog, "n2rC7YX8Mzz154E9USQBvseY7a0=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    likes: PropTypes.number.isRequired,
    user: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
  }).isRequired,
  handleLike: PropTypes.func.isRequired,
  handleRemove: PropTypes.func.isRequired,
  currentUser: PropTypes.object.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("D:/carlo/OneDrive/Documentos/Carrera/Proyectos/Visual Studio Code/fullstackopen_exercises/part5/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0NROzs7Ozs7Ozs7Ozs7Ozs7OztBQXRDUixPQUFPQSxlQUFlO0FBQ3RCLFNBQVNDLGdCQUFnQjtBQUV6QixNQUFNQyxPQUFPQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBWUM7QUFBQUEsRUFBY0M7QUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDaEUsUUFBTSxDQUFDQyxhQUFhQyxjQUFjLElBQUlSLFNBQVMsS0FBSztBQUVwRCxRQUFNUyxZQUFZO0FBQUEsSUFDaEJDLFNBQVM7QUFBQSxJQUNUQyxRQUFRO0FBQUEsSUFDUkMsY0FBYztBQUFBLElBQ2RDLGNBQWM7QUFBQSxJQUNkQyxZQUFZO0FBQUEsRUFDZDtBQUVBLFFBQU1DLFdBQVdBLE1BQU07QUFDckJaLGVBQVc7QUFBQSxNQUNULEdBQUdEO0FBQUFBLE1BQ0hjLE9BQU9kLEtBQUtjLFFBQVE7QUFBQSxNQUNwQkMsTUFBTWYsS0FBS2UsS0FBS0MsTUFBTWhCLEtBQUtlO0FBQUFBLElBQzdCLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUUsYUFBYUEsTUFBTTtBQUN2QixRQUFJQyxPQUFPQyxRQUFTLGdCQUFlbkIsS0FBS29CLEtBQU0sUUFBT3BCLEtBQUtxQixNQUFPLEdBQUUsR0FBRztBQUNwRW5CLG1CQUFhRixJQUFJO0FBQUEsSUFDbkI7QUFBQSxFQUNGO0FBR0EsUUFBTXNCLFVBQVV0QixLQUFLZSxTQUNuQmYsS0FBS2UsS0FBS1EsYUFBYXBCLFlBQVlvQixZQUNuQ3ZCLEtBQUtlLFNBQVNaLFlBQVlhO0FBRzVCLFNBQ0UsdUJBQUMsU0FBSSxPQUFPVCxXQUFXLFdBQVUsUUFDL0I7QUFBQSwyQkFBQyxTQUNFUDtBQUFBQSxXQUFLb0I7QUFBQUEsTUFBTTtBQUFBLE1BQUVwQixLQUFLcUI7QUFBQUEsTUFDbkIsdUJBQUMsWUFBTyxTQUFTLE1BQU1mLGVBQWUsQ0FBQ0QsV0FBVyxHQUMvQ0Esd0JBQWMsU0FBUyxVQUQxQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0NBLGVBQ0MsdUJBQUMsU0FBSSxXQUFVLGVBQ2I7QUFBQSw2QkFBQyxTQUFLTCxlQUFLd0IsT0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmLHVCQUFDLFNBQUk7QUFBQTtBQUFBLFFBQ0l4QixLQUFLYztBQUFBQSxRQUNaLHVCQUFDLFlBQU8sU0FBU0QsVUFBVSxvQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFdBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsU0FBS2IsZUFBS2UsUUFBUWYsS0FBS2UsS0FBS1UsUUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQztBQUFBLE1BQ2pDSCxXQUNDLHVCQUFDLFlBQU8sU0FBU0wsWUFBWSxPQUFPO0FBQUEsUUFBRUwsWUFBWTtBQUFBLFFBQU9jLE9BQU87QUFBQSxNQUFRLEdBQUcsc0JBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0FwQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNCQTtBQUVKO0FBQUN0QixHQXhES0wsTUFBSTtBQUFBNEIsS0FBSjVCO0FBMEROQSxLQUFLNkIsWUFBWTtBQUFBLEVBQ2Y1QixNQUFNSCxVQUFVZ0MsTUFBTTtBQUFBLElBQ3BCYixJQUFJbkIsVUFBVWlDLE9BQU9DO0FBQUFBLElBQ3JCWCxPQUFPdkIsVUFBVWlDLE9BQU9DO0FBQUFBLElBQ3hCVixRQUFReEIsVUFBVWlDLE9BQU9DO0FBQUFBLElBQ3pCUCxLQUFLM0IsVUFBVWlDLE9BQU9DO0FBQUFBLElBQ3RCakIsT0FBT2pCLFVBQVVtQyxPQUFPRDtBQUFBQSxJQUN4QmhCLE1BQU1sQixVQUFVb0MsVUFBVSxDQUN4QnBDLFVBQVVpQyxRQUNWakMsVUFBVXFDLE1BQU0sQ0FDakI7QUFBQSxFQUNILENBQUMsRUFBRUg7QUFBQUEsRUFDSDlCLFlBQVlKLFVBQVVzQyxLQUFLSjtBQUFBQSxFQUMzQjdCLGNBQWNMLFVBQVVzQyxLQUFLSjtBQUFBQSxFQUM3QjVCLGFBQWFOLFVBQVVxQyxPQUFPSDtBQUNoQztBQUVBLGVBQWVoQztBQUFJLElBQUE0QjtBQUFBUyxhQUFBVCxJQUFBIiwibmFtZXMiOlsiUHJvcFR5cGVzIiwidXNlU3RhdGUiLCJCbG9nIiwiYmxvZyIsImhhbmRsZUxpa2UiLCJoYW5kbGVSZW1vdmUiLCJjdXJyZW50VXNlciIsIl9zIiwic2hvd0RldGFpbHMiLCJzZXRTaG93RGV0YWlscyIsImJsb2dTdHlsZSIsInBhZGRpbmciLCJib3JkZXIiLCJtYXJnaW5Cb3R0b20iLCJib3JkZXJSYWRpdXMiLCJiYWNrZ3JvdW5kIiwibGlrZUJsb2ciLCJsaWtlcyIsInVzZXIiLCJpZCIsInJlbW92ZUJsb2ciLCJ3aW5kb3ciLCJjb25maXJtIiwidGl0bGUiLCJhdXRob3IiLCJpc093bmVyIiwidXNlcm5hbWUiLCJ1cmwiLCJuYW1lIiwiY29sb3IiLCJfYyIsInByb3BUeXBlcyIsInNoYXBlIiwic3RyaW5nIiwiaXNSZXF1aXJlZCIsIm51bWJlciIsIm9uZU9mVHlwZSIsIm9iamVjdCIsImZ1bmMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCbG9nLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG5jb25zdCBCbG9nID0gKHsgYmxvZywgaGFuZGxlTGlrZSwgaGFuZGxlUmVtb3ZlLCBjdXJyZW50VXNlciB9KSA9PiB7XHJcbiAgY29uc3QgW3Nob3dEZXRhaWxzLCBzZXRTaG93RGV0YWlsc10gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgY29uc3QgYmxvZ1N0eWxlID0ge1xyXG4gICAgcGFkZGluZzogMTAsXHJcbiAgICBib3JkZXI6ICcxcHggc29saWQgI2NjYycsXHJcbiAgICBtYXJnaW5Cb3R0b206IDUsXHJcbiAgICBib3JkZXJSYWRpdXM6IDQsXHJcbiAgICBiYWNrZ3JvdW5kOiAnI2Y5ZjlmOSdcclxuICB9XHJcblxyXG4gIGNvbnN0IGxpa2VCbG9nID0gKCkgPT4ge1xyXG4gICAgaGFuZGxlTGlrZSh7XHJcbiAgICAgIC4uLmJsb2csXHJcbiAgICAgIGxpa2VzOiBibG9nLmxpa2VzICsgMSxcclxuICAgICAgdXNlcjogYmxvZy51c2VyLmlkIHx8IGJsb2cudXNlclxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGNvbnN0IHJlbW92ZUJsb2cgPSAoKSA9PiB7XHJcbiAgICBpZiAod2luZG93LmNvbmZpcm0oYFJlbW92ZSBibG9nIFwiJHtibG9nLnRpdGxlfVwiIGJ5ICR7YmxvZy5hdXRob3J9P2ApKSB7XHJcbiAgICAgIGhhbmRsZVJlbW92ZShibG9nKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gRWwgdXN1YXJpbyBwdWVkZSBlc3RhciBjb21vIG9iamV0byBvIGlkLCBwb3IgZXNvIGxhIGNvbXBhcmFjacOzblxyXG4gIGNvbnN0IGlzT3duZXIgPSBibG9nLnVzZXIgJiYgKFxyXG4gICAgYmxvZy51c2VyLnVzZXJuYW1lID09PSBjdXJyZW50VXNlci51c2VybmFtZSB8fFxyXG4gICAgYmxvZy51c2VyID09PSBjdXJyZW50VXNlci5pZFxyXG4gIClcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0gY2xhc3NOYW1lPVwiYmxvZ1wiPlxyXG4gICAgICA8ZGl2PlxyXG4gICAgICAgIHtibG9nLnRpdGxlfSB7YmxvZy5hdXRob3J9XHJcbiAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93RGV0YWlscyghc2hvd0RldGFpbHMpfT5cclxuICAgICAgICAgIHtzaG93RGV0YWlscyA/ICdoaWRlJyA6ICd2aWV3J31cclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICAgIHtzaG93RGV0YWlscyAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJibG9nRGV0YWlsc1wiPlxyXG4gICAgICAgICAgPGRpdj57YmxvZy51cmx9PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICBsaWtlcyB7YmxvZy5saWtlc31cclxuICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtsaWtlQmxvZ30+bGlrZTwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PntibG9nLnVzZXIgJiYgYmxvZy51c2VyLm5hbWV9PC9kaXY+XHJcbiAgICAgICAgICB7aXNPd25lciAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17cmVtb3ZlQmxvZ30gc3R5bGU9e3sgYmFja2dyb3VuZDogJ3JlZCcsIGNvbG9yOiAnd2hpdGUnIH19PlxyXG4gICAgICAgICAgICAgIHJlbW92ZVxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuXHJcbkJsb2cucHJvcFR5cGVzID0ge1xyXG4gIGJsb2c6IFByb3BUeXBlcy5zaGFwZSh7XHJcbiAgICBpZDogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZCxcclxuICAgIGF1dGhvcjogUHJvcFR5cGVzLnN0cmluZy5pc1JlcXVpcmVkLFxyXG4gICAgdXJsOiBQcm9wVHlwZXMuc3RyaW5nLmlzUmVxdWlyZWQsXHJcbiAgICBsaWtlczogUHJvcFR5cGVzLm51bWJlci5pc1JlcXVpcmVkLFxyXG4gICAgdXNlcjogUHJvcFR5cGVzLm9uZU9mVHlwZShbXHJcbiAgICAgIFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICAgIFByb3BUeXBlcy5vYmplY3RcclxuICAgIF0pXHJcbiAgfSkuaXNSZXF1aXJlZCxcclxuICBoYW5kbGVMaWtlOiBQcm9wVHlwZXMuZnVuYy5pc1JlcXVpcmVkLFxyXG4gIGhhbmRsZVJlbW92ZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcclxuICBjdXJyZW50VXNlcjogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJsb2ciXSwiZmlsZSI6IkQ6L2NhcmxvL09uZURyaXZlL0RvY3VtZW50b3MvQ2FycmVyYS9Qcm95ZWN0b3MvVmlzdWFsIFN0dWRpbyBDb2RlL2Z1bGxzdGFja29wZW5fZXhlcmNpc2VzL3BhcnQ1L3NyYy9jb21wb25lbnRzL0Jsb2cuanN4In0=