import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=6f5ec47e";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=6f5ec47e";
export default require_react();
//# sourceMappingURL=react.js.map
